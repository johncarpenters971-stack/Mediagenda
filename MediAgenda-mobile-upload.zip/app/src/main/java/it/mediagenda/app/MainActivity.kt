package it.mediagenda.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

 data class Medicine(val name: String, val detail: String, val time: String, val status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediAgendaApp() }
    }
}

@Composable
fun MediAgendaApp() {
    val demo = listOf(
        Medicine("Medicinale A", "Dose inserita dall'utente", "08:00", "Registrato"),
        Medicine("Medicinale B", "Dose inserita dall'utente", "14:00", "Da ricordare"),
        Medicine("Medicinale C", "Dose inserita dall'utente", "20:00", "In programma")
    )
    var selectedTab by remember { mutableStateOf("Home") }
    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Medicinali", "Diario", "Scorte", "Impostazioni").forEach { tab ->
                        NavigationBarItem(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) }, icon = { Text(tab.take(1)) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                Text("MEDIAGENDA", style = MaterialTheme.typography.headlineMedium)
                Text("Ricorda. Registra. Organizza.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(20.dp))
                when (selectedTab) {
                    "Home" -> {
                        Text("I tuoi promemoria", style = MaterialTheme.typography.titleLarge)
                        Text("Demo interfaccia — i dati non sono ancora salvati")
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(demo) { item -> MedicineCard(item) }
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { selectedTab = "Medicinali" }, modifier = Modifier.fillMaxWidth()) { Text("Gestisci medicinali") }
                    }
                    "Medicinali" -> {
                        Text("Archivio medicinali", style = MaterialTheme.typography.titleLarge)
                        Text("Prossimo passo: modulo di inserimento, programmazione e scorte.")
                        Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("+ Aggiungi medicinale (prototipo)") }
                    }
                    "Diario" -> Text("Diario delle assunzioni — in sviluppo")
                    "Scorte" -> Text("Scorte e rifornimenti — in sviluppo")
                    else -> Text("Impostazioni notifiche, privacy e backup — in sviluppo")
                }
            }
        }
    }
}

@Composable
fun MedicineCard(item: Medicine) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(item.name, style = MaterialTheme.typography.titleMedium)
            Text(item.detail)
            Text("Orario: ${item.time}")
            Text("Stato: ${item.status}")
        }
    }
}
