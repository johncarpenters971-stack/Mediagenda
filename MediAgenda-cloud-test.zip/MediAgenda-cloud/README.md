# MediAgenda — Android starter project

This is a starter scaffold for the MediAgenda Android app. The home screen is a prototype and uses demo data only. No medication reminders are active and no medication data is persisted yet.

## Open
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync.
4. Run on an Android emulator or device.

## Planned next steps
- Medication data model and local database
- Add/edit medicine form and schedules
- Notifications and alarm handling
- Intake history and inventory
- Expiry alerts, backup, accessibility and privacy review

This app is an organizational reminder only, not medical advice or dosing guidance.
